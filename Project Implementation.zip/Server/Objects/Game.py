class Game:
    def __init__(self):
        self._players = []
